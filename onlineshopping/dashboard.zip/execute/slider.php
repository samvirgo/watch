
<!DOCTYPE html>
<html>
<head>
	<title>Softech Australia</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	
	<!-- Start  HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<!-- End  HEAD section -->

</head>
<body style="background-color:white;margin:auto">
	
	<!-- Start BODY section --> <!-- add to the <body> of your page -->
	<div id="wowslider-container1">
	<div class="ws_images"><ul>
		<li><img src="img/banner2.jpg" alt="banner2" title="banner2" id="wows1_0"/></li>
		<li><img src="img/banner3.jpg" alt="banner3" title="banner3" id="wows1_1"/></li>
		<li><img src="img/banner4.jpg" alt="banner4" title="banner4" id="wows1_2"/></li>
		<li><img src="img/banner5.jpg" alt="full screen slider" title="full screen slider" id="wows1_3"/></li>
		<li><img src="img/banner1.jpg" alt="banner1" title="banner1" id="wows1_4"/></li>
	</ul></div>
	</div>	
	<script type="text/javascript" src="engine1/wowslider.js"></script>
	<script type="text/javascript" src="engine1/script.js"></script>
	<!-- End  BODY section -->

</body>
</html>