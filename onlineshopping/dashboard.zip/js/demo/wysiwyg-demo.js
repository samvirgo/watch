//Summernote WYSIWYG Initialization and Custom Height
$(document).ready(function() {
    $('#summernote').summernote({
        height: 400
    });
});
